<?php
require_once __DIR__ . '/config.php';

define('SEV_VERIFY_TABLE', 'serbiaevisa');

/* ── DB connection ── */
function sev_db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    $dsn = sprintf(
        'mysql:host=%s;port=%s;dbname=%s;charset=%s',
        sev_mysql_host(),
        sev_mysql_port(),
        sev_mysql_db(),
        sev_mysql_charset()
    );
    $pdo = new PDO($dsn, sev_mysql_user(), sev_mysql_pass(), [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    return $pdo;
}

/* ── Lookup by passport + evisa ID (QR scan) ── */
function sev_find_by_passport_and_evisa(string $passport, string $evisaId): ?array
{
    $passport = strtoupper(trim($passport));
    $evisaId  = strtoupper(trim($evisaId));
    if ($passport === '' || $evisaId === '') return null;

    $stmt = sev_db()->prepare(
        'SELECT * FROM `' . SEV_VERIFY_TABLE . '`
         WHERE UPPER(`passport_number`) = :p
           AND UPPER(`visa_number`)     = :e
         LIMIT 1'
    );
    $stmt->execute(['p' => $passport, 'e' => $evisaId]);
    $row = $stmt->fetch();
    return is_array($row) ? $row : null;
}

/* ── Lookup by keyword (passport OR evisa ID) ── */
function sev_find_by_keyword(string $keyword): ?array
{
    $keyword = strtoupper(trim($keyword));
    if ($keyword === '') return null;

    $stmt = sev_db()->prepare(
        'SELECT * FROM `' . SEV_VERIFY_TABLE . '`
         WHERE UPPER(`passport_number`) = :kw
            OR UPPER(`visa_number`)     = :kw
         LIMIT 1'
    );
    $stmt->execute(['kw' => $keyword]);
    $row = $stmt->fetch();
    return is_array($row) ? $row : null;
}

/* ── Lookup by Application ID + eVisa ID ── */
function sev_find_by_application_and_evisa(string $appId, string $evisaId): ?array
{
    $evisaId = strtoupper(trim($evisaId));
    $appId   = trim($appId);
    if ($appId === '' || $evisaId === '') return null;

    $stmt = sev_db()->prepare(
        'SELECT * FROM `' . SEV_VERIFY_TABLE . '`
         WHERE UPPER(`visa_number`) = :e
         LIMIT 1'
    );
    $stmt->execute(['e' => $evisaId]);
    $row = $stmt->fetch();
    if (!is_array($row)) return null;

    // PHP-side verify applicationId from remarks JSON
    $rm = json_decode((string)($row['remarks'] ?? ''), true);
    if (!is_array($rm)) $rm = [];
    $stored = trim((string)($rm['applicationId'] ?? ''));
    return (strcasecmp($stored, $appId) === 0) ? $row : null;
}

/* ── Helpers ── */
function sev_fmt_date(string $d): string
{
    $d = trim($d);
    if ($d === '') return '—';
    $ts = strtotime($d);
    return $ts !== false ? date('d.m.Y', $ts) : $d;
}

function sev_h(string $v): string
{
    return htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
}
